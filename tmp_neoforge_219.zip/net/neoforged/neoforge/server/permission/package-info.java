/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.neoforged.neoforge.server.permission;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.MethodsReturnNonnullByDefault;
